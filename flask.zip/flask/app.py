from flask import Flask, render_template, request, redirect, url_for
import requests

app = Flask(__name__)
WEBEX_API_BASE = 'https://webexapis.com/v1'

# Fetch the user's info
def get_user_info(access_token):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.get(f'{WEBEX_API_BASE}/people/me', headers=headers)
    return response.json() if response.status_code == 200 else None

# Fetch the list of rooms
def get_rooms(access_token):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.get(f'{WEBEX_API_BASE}/rooms', headers=headers)
    return response.json().get('items', []) if response.status_code == 200 else None

# Send a message to a room
def send_message(access_token, room_id, text):
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    data = {
        'roomId': room_id,
        'text': text
    }
    response = requests.post(f'{WEBEX_API_BASE}/messages', headers=headers, json=data)
    return response.status_code == 200

# Create a new room
def create_webex_room(access_token, title):
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    data = {
        'title': title
    }
    response = requests.post(f'{WEBEX_API_BASE}/rooms', headers=headers, json=data)
    return response.status_code == 200

# Delete a room
def delete_webex_room(access_token, room_id):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.delete(f'{WEBEX_API_BASE}/rooms/{room_id}', headers=headers)
    return response.status_code == 204  # Successful deletion returns HTTP 204

# Test Webex connection
def test_webex_connection(access_token):
    user_info = get_user_info(access_token)
    return user_info is not None

# Flask routes
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        access_token = request.form.get('access_token')
        user_info = get_user_info(access_token)
        if user_info:
            return redirect(url_for('menu', access_token=access_token))
        else:
            return "Invalid access token. Please try again.", 400
    return render_template('index.html')

@app.route('/menu/<access_token>', methods=['GET'])
def menu(access_token):
    return render_template('menu.html', access_token=access_token)

@app.route('/test_connection/<access_token>', methods=['GET'])
def test_connection(access_token):
    success = test_webex_connection(access_token)
    if success:
        return render_template('test_connection.html', status="Connection successful!", access_token=access_token)
    return render_template('test_connection.html', status="Connection failed.", access_token=access_token)

@app.route('/user_info/<access_token>', methods=['GET'])
def user_info(access_token):
    user_info = get_user_info(access_token)
    if user_info:
        return render_template('user_info.html', user_info=user_info, access_token=access_token)
    return "Failed to retrieve user info.", 400

@app.route('/rooms/<access_token>', methods=['GET'])
def rooms(access_token):
    rooms = get_rooms(access_token)
    if rooms is not None:
        return render_template('rooms.html', rooms=rooms[:5], access_token=access_token)  # Limit to 5 rooms
    return "Failed to retrieve rooms.", 400

@app.route('/create_room/<access_token>', methods=['POST'])
def create_room(access_token):
    title = request.form.get('title')
    success = create_webex_room(access_token, title)
    if success:
        return redirect(url_for('rooms', access_token=access_token))  # Redirect to rooms page after room creation
    return "Failed to create room.", 400

@app.route('/send_message/<access_token>', methods=['POST'])
def send_message_route(access_token):
    room_id = request.form.get('room_id')
    message = request.form.get('message')
    if send_message(access_token, room_id, message):
        return redirect(url_for('rooms', access_token=access_token))  # Redirect to rooms page after message is sent
    return "Failed to send message.", 400

# Route for deleting a room
@app.route('/delete_room/<access_token>/<room_id>', methods=['POST'])
def delete_room(access_token, room_id):
    success = delete_webex_room(access_token, room_id)
    if success:
        return redirect(url_for('rooms', access_token=access_token))  # Redirect to rooms page after deletion
    return "Failed to delete room.", 400

# Route for logging out
@app.route('/logout', methods=['GET'])
def logout():
    # Redirect to the index page (login page) after logging out
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
